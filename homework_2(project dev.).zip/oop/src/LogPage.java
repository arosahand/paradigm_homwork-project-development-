import java.sql.*;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.JOptionPane;
import javax.swing.UIManager;


public class LogPage extends javax.swing.JFrame {

     Connection con;
    PreparedStatement pst;
    ResultSet rs;
    public LogPage() {
        initComponents();
        oop();
    }

    
    
    void oop(){
         try{
                con=DriverManager.getConnection("jdbc:mysql://localhost:3308/pharmacy", "root","");
                System.out.println("Connection Succsseful");
        }catch(SQLException e){
            System.out.println(e);
            
        }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        rol = new javax.swing.JComboBox<>();
        welc = new javax.swing.JLabel();
        extbt = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Regbt = new javax.swing.JButton();
        Loginbt = new javax.swing.JButton();
        PasswordLable = new javax.swing.JLabel();
        Password = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Username = new javax.swing.JTextField();
        UsernameLable = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LogIn");
        setAlwaysOnTop(true);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel1.setLayout(null);

        rol.setBackground(new java.awt.Color(179, 216, 168));
        rol.setForeground(new java.awt.Color(0, 0, 0));
        rol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Managing role", "Admin", "DrugStorage", "FliudStorage", "SupplyStorage" }));
        jPanel1.add(rol);
        rol.setBounds(420, 330, 160, 40);
        jPanel1.add(welc);
        welc.setBounds(230, 420, 220, 20);

        extbt.setBackground(new java.awt.Color(79, 149, 157));
        extbt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        extbt.setForeground(new java.awt.Color(0, 0, 0));
        extbt.setText("Exit");
        extbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                extbtActionPerformed(evt);
            }
        });
        jPanel1.add(extbt);
        extbt.setBounds(700, 490, 72, 27);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Don't have an account?");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(230, 480, 170, 30);

        Regbt.setBackground(new java.awt.Color(79, 149, 157));
        Regbt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Regbt.setForeground(new java.awt.Color(0, 0, 0));
        Regbt.setText("Register");
        Regbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegbtActionPerformed(evt);
            }
        });
        jPanel1.add(Regbt);
        Regbt.setBounds(400, 480, 110, 27);

        Loginbt.setBackground(new java.awt.Color(79, 149, 157));
        Loginbt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Loginbt.setForeground(new java.awt.Color(0, 0, 0));
        Loginbt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagePharmacy/log_3601824.png"))); // NOI18N
        Loginbt.setText("Login");
        Loginbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginbtActionPerformed(evt);
            }
        });
        jPanel1.add(Loginbt);
        Loginbt.setBounds(560, 390, 100, 31);

        PasswordLable.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        PasswordLable.setForeground(new java.awt.Color(0, 0, 0));
        PasswordLable.setText("Password");
        jPanel1.add(PasswordLable);
        PasswordLable.setBounds(320, 270, 90, 50);

        Password.setBackground(new java.awt.Color(179, 216, 168));
        Password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Password.setForeground(new java.awt.Color(0, 0, 0));
        Password.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(Password);
        Password.setBounds(420, 280, 160, 30);
        jPanel1.add(jLabel2);
        jLabel2.setBounds(550, 100, 70, 80);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Login");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(470, 190, 70, 30);

        Username.setBackground(new java.awt.Color(179, 216, 168));
        Username.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Username.setForeground(new java.awt.Color(0, 0, 0));
        Username.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(Username);
        Username.setBounds(420, 230, 160, 30);

        UsernameLable.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        UsernameLable.setForeground(new java.awt.Color(0, 0, 0));
        UsernameLable.setText("Username");
        jPanel1.add(UsernameLable);
        UsernameLable.setBounds(320, 230, 90, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagePharmacy/person_13924070.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(470, 110, 70, 80);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagePharmacy/2148502965 (1).jpg"))); // NOI18N
        jLabel4.setText("jLabel4");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(0, 0, 910, 630);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 908, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LoginbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginbtActionPerformed
  try {
   String sql = "SELECT * FROM employee WHERE Username = ? AND Password = ? AND Role = ?";
    pst = con.prepareStatement(sql);
    pst.setString(1, Username.getText());
    pst.setString(2, Password.getText());
    pst.setString(3, rol.getSelectedItem().toString()); 

    rs = pst.executeQuery();

    
    if (rs.next()) {
        JOptionPane.showMessageDialog(rootPane, "Login Successful as " + rs.getString("Role"));

        String username = rs.getString("Username");
        String roleValue = rs.getString("Role");

        if (roleValue.equalsIgnoreCase("Admin")) {
            new AdminDash(username,roleValue).setVisible(true);
        } else if (roleValue.equalsIgnoreCase("DrugStorage")) {
            new MedicineStor(username, roleValue).setVisible(true);
        } 

        this.dispose();
    } else {
        JOptionPane.showMessageDialog(rootPane, "Invalid Username or Password");
    }
} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(rootPane, "An error occurred. Please try again.");
    }//GEN-LAST:event_LoginbtActionPerformed
    }
    private void RegbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegbtActionPerformed
          reg r=new reg();
       r.setVisible(true);
        this.setVisible(false);
        
        
        
        
        
    }//GEN-LAST:event_RegbtActionPerformed

    private void extbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_extbtActionPerformed
       System.exit(0);
    }//GEN-LAST:event_extbtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       try {
    UIManager.setLookAndFeel( new FlatLightLaf() );
} catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}

        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LogPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Loginbt;
    private javax.swing.JPasswordField Password;
    private javax.swing.JLabel PasswordLable;
    private javax.swing.JButton Regbt;
    private javax.swing.JTextField Username;
    private javax.swing.JLabel UsernameLable;
    private javax.swing.JButton extbt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> rol;
    private javax.swing.JLabel welc;
    // End of variables declaration//GEN-END:variables
}
