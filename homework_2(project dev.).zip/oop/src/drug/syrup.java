
package drug;


public class syrup extends medicine {
     private String ml;
    
    
   public void setml(String ml){
       this.ml=ml;
   } 
    
   public String getml(){
       return ml;
   }
    
    
    
}
