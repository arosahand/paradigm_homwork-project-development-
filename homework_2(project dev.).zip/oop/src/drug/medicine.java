
package drug;


public class medicine {
     private int ID;
    private String NameDrug;
    private String ProductionDate;
    private String ExpireDate;
    private int Price;
    private int Quantity;
    private int Temp;
    private String DateIssued;
    
    
    
    public void setId(int Id){
this.ID=Id;}

public int getId(){
return ID;}
    
    public void setName(String Name){
this.NameDrug=Name;}

public String getName(){
return NameDrug;}

public void setProductionDate(String ProductionDate){
this.ProductionDate=ProductionDate;}

public String getProductionDate(){
return ProductionDate;}

public void setExpireDate(String ExpireDate){
this.ExpireDate=ExpireDate;}




public String getExpireDate(){
return ExpireDate;



}
    
  
    
   public void setPrice(int pr){
       this.Price=pr;
   } 
    
    public int getPrice(){
        return Price;
    }
    
    
    public void setQuantity(int quant){
        this.Quantity=quant;
    }
    
    
    
    public int getQuantity(){
        return Quantity;
    }
    
    public void setTemp(int temp){
        this.Temp=temp;
    }
    
    
    public int getTemp(){
        return Temp;
    }
    
    public void setDate(String dt){
        this.DateIssued=dt;
    }
    
    public String getDate(){
        return DateIssued;
    }
}
