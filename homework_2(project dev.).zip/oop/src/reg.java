import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.UIManager;

public class reg extends javax.swing.JFrame {

    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    public reg() {
        initComponents();
        oop();
    }

   
    void oop(){
         try{
                con=DriverManager.getConnection("jdbc:mysql://localhost:3308/pharmacy", "root","");
                System.out.println("Connection Succsseful");
        }catch(SQLException e){
            System.out.println(e);
            
        }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        retype = new javax.swing.JLabel();
        role = new javax.swing.JComboBox<>();
        Password1 = new javax.swing.JPasswordField();
        regsucc = new javax.swing.JLabel();
        extbt = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Register = new javax.swing.JButton();
        loginbt = new javax.swing.JButton();
        PasswordLable = new javax.swing.JLabel();
        Password = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Username = new javax.swing.JTextField();
        UsernameLable = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Register");

        jPanel1.setLayout(null);

        retype.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        retype.setForeground(new java.awt.Color(0, 0, 0));
        retype.setText("Re-type Password");
        jPanel1.add(retype);
        retype.setBounds(260, 270, 160, 60);

        role.setBackground(new java.awt.Color(179, 216, 168));
        role.setForeground(new java.awt.Color(0, 0, 0));
        role.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Managing role", "Admin", "DrugStorage", "FliudStorage", "SupplyStorage" }));
        role.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roleActionPerformed(evt);
            }
        });
        jPanel1.add(role);
        role.setBounds(420, 330, 160, 40);

        Password1.setBackground(new java.awt.Color(179, 216, 168));
        Password1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Password1.setForeground(new java.awt.Color(0, 0, 0));
        Password1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(Password1);
        Password1.setBounds(420, 290, 160, 30);

        regsucc.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        regsucc.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(regsucc);
        regsucc.setBounds(370, 330, 160, 0);

        extbt.setBackground(new java.awt.Color(79, 149, 157));
        extbt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        extbt.setForeground(new java.awt.Color(0, 0, 0));
        extbt.setText("Exit");
        extbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                extbtActionPerformed(evt);
            }
        });
        jPanel1.add(extbt);
        extbt.setBounds(700, 490, 72, 27);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Already have an account?");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(230, 480, 190, 30);

        Register.setBackground(new java.awt.Color(79, 149, 157));
        Register.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Register.setForeground(new java.awt.Color(0, 0, 0));
        Register.setText("Sign Up");
        Register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterActionPerformed(evt);
            }
        });
        jPanel1.add(Register);
        Register.setBounds(540, 400, 110, 27);

        loginbt.setBackground(new java.awt.Color(79, 149, 157));
        loginbt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        loginbt.setForeground(new java.awt.Color(0, 0, 0));
        loginbt.setText("Login");
        loginbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbtActionPerformed(evt);
            }
        });
        jPanel1.add(loginbt);
        loginbt.setBounds(410, 480, 100, 27);

        PasswordLable.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        PasswordLable.setForeground(new java.awt.Color(0, 0, 0));
        PasswordLable.setText("Password");
        jPanel1.add(PasswordLable);
        PasswordLable.setBounds(330, 230, 130, 50);

        Password.setBackground(new java.awt.Color(179, 216, 168));
        Password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Password.setForeground(new java.awt.Color(0, 0, 0));
        Password.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(Password);
        Password.setBounds(420, 240, 160, 30);
        jPanel1.add(jLabel2);
        jLabel2.setBounds(550, 100, 70, 80);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Register");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(450, 120, 100, 30);

        Username.setBackground(new java.awt.Color(179, 216, 168));
        Username.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Username.setForeground(new java.awt.Color(0, 0, 0));
        Username.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(Username);
        Username.setBounds(420, 190, 160, 30);

        UsernameLable.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        UsernameLable.setForeground(new java.awt.Color(0, 0, 0));
        UsernameLable.setText("Username");
        jPanel1.add(UsernameLable);
        UsernameLable.setBounds(330, 180, 90, 40);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagePharmacy/2148502965 (1).jpg"))); // NOI18N
        jLabel4.setText("jLabel4");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(0, 0, 910, 630);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 908, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 628, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbtActionPerformed
      LogPage l=new LogPage();
      l.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_loginbtActionPerformed

    private void extbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_extbtActionPerformed
      System.exit(0);
    }//GEN-LAST:event_extbtActionPerformed

    private void RegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterActionPerformed
        
        try {
            String sql="INSERT INTO `employee`( `Username`, `Password`, `Role`) VALUES (?,?,?)";
            if(Password.getText().equals(Password1.getText())){
              pst=con.prepareStatement(sql);
                       
                       pst.setString(1, Username.getText());
                       pst.setString(2, Password.getText());
                       pst.setString(3, role.getSelectedItem().toString());
                       
                        
                            pst.executeUpdate();
           JOptionPane.showMessageDialog(rootPane, "Account Created");
                        }
                       
            else{ 
                           JOptionPane.showMessageDialog(rootPane, "Password dont match, Please Check your password and try again");
            }
            
            
            
            
            
            
        } catch (Exception e) {
            
        }
        
        
        
        
        
        
        
        
    }//GEN-LAST:event_RegisterActionPerformed

    private void roleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_roleActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       try {
    UIManager.setLookAndFeel( new FlatLightLaf() );
} catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LogPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField Password;
    private javax.swing.JPasswordField Password1;
    private javax.swing.JLabel PasswordLable;
    private javax.swing.JButton Register;
    private javax.swing.JTextField Username;
    private javax.swing.JLabel UsernameLable;
    private javax.swing.JButton extbt;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton loginbt;
    private javax.swing.JLabel regsucc;
    private javax.swing.JLabel retype;
    private javax.swing.JComboBox<String> role;
    // End of variables declaration//GEN-END:variables
}
