

import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.UIManager;
/*

 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Aro
 */
public class MedicineStor extends javax.swing.JFrame {

  Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    public MedicineStor(String username, String role) {
        initComponents();
        datetime();
        oop();
        showdata();
        showadddata();
        showupdata();
        
        
        Welcome.setText("Logged in as: " + username + " (" + role + ")");
        
        
        
    }
    
    public MedicineStor(){
         initComponents();
          
    }
    
    
      void oop(){
         try{
                con=DriverManager.getConnection("jdbc:mysql://localhost:3308/pharmacy", "root","");
                System.out.println("Connection Succsseful");
        }catch(SQLException e){
            System.out.println(e);
        }
    }
void showdata(){
        try {
            String sql="SELECT `Day`, `ID`, `Name`, `Balance`, `Dosage Form`, `Dosage type`, `Expiry date` FROM `drugs` ";
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
 
     
void showadddata(){
        try {
            String sql="SELECT `Day`,`Name`, `Quantity`, `Dosage Form`, `Dosage type`, `Expiry date` FROM `drugs`";
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            tableadd.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

void showupdata(){
        try {
            String sql="SELECT `Day`,`ID`,`Name`, `Balance`, `Dosage Form`, `Dosage type`, `Expiry date` FROM `drugs`";
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            tableup.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bottpanel = new javax.swing.JPanel();
        add = new javax.swing.JButton();
        update = new javax.swing.JButton();
        view = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        tabs = new javax.swing.JTabbedPane();
        addtab = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        quant = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        combo = new javax.swing.JComboBox<>();
        dosage = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        addbt = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableadd = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        day = new javax.swing.JTextField();
        ex = new javax.swing.JTextField();
        ipttab = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        dayup = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableup = new javax.swing.JTable();
        balanceup = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        exup = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        upbott = new javax.swing.JButton();
        idup = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        del = new javax.swing.JButton();
        viewtab = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        Welcome = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Storage");
        setMaximumSize(new java.awt.Dimension(1920, 1080));
        setMinimumSize(new java.awt.Dimension(870, 568));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bottpanel.setBackground(new java.awt.Color(179, 216, 168));

        add.setBackground(new java.awt.Color(61, 141, 122));
        add.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        add.setForeground(new java.awt.Color(0, 0, 0));
        add.setText("Add ");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        update.setBackground(new java.awt.Color(61, 141, 122));
        update.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        update.setForeground(new java.awt.Color(0, 0, 0));
        update.setText("Update/Delete");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        view.setBackground(new java.awt.Color(61, 141, 122));
        view.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        view.setForeground(new java.awt.Color(0, 0, 0));
        view.setText("View");
        view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewActionPerformed(evt);
            }
        });

        exit.setBackground(new java.awt.Color(61, 141, 122));
        exit.setForeground(new java.awt.Color(0, 0, 0));
        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        logout.setBackground(new java.awt.Color(61, 141, 122));
        logout.setForeground(new java.awt.Color(0, 0, 0));
        logout.setText("Logout");
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bottpanelLayout = new javax.swing.GroupLayout(bottpanel);
        bottpanel.setLayout(bottpanelLayout);
        bottpanelLayout.setHorizontalGroup(
            bottpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bottpanelLayout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addGroup(bottpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(update, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(54, Short.MAX_VALUE))
            .addGroup(bottpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logout)
                .addGap(26, 26, 26))
        );
        bottpanelLayout.setVerticalGroup(
            bottpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bottpanelLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(view, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 167, Short.MAX_VALUE)
                .addGroup(bottpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exit)
                    .addComponent(logout))
                .addGap(57, 57, 57))
        );

        getContentPane().add(bottpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 250, 470));

        tabs.setBackground(new java.awt.Color(64, 64, 0));

        addtab.setBackground(new java.awt.Color(163, 209, 198));
        addtab.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Add Product");

        name.setBackground(new java.awt.Color(79, 149, 157));
        name.setForeground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Dosage type");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Day");

        quant.setBackground(new java.awt.Color(79, 149, 157));
        quant.setForeground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Expirey Date");

        combo.setBackground(new java.awt.Color(79, 149, 157));
        combo.setForeground(new java.awt.Color(255, 255, 255));
        combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Dosage form", "Tablet", "Syrup" }));

        dosage.setBackground(new java.awt.Color(79, 149, 157));
        dosage.setForeground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Quantity");

        addbt.setText("Add");
        addbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbtActionPerformed(evt);
            }
        });

        jButton5.setText("Clear all");

        tableadd.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Day", "Name", "Quantity", "Dosage Form", "Dosage type", "Exipry date"
            }
        ));
        jScrollPane2.setViewportView(tableadd);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Name");

        day.setBackground(new java.awt.Color(79, 149, 157));
        day.setForeground(new java.awt.Color(255, 255, 255));

        ex.setBackground(new java.awt.Color(79, 149, 157));
        ex.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout addtabLayout = new javax.swing.GroupLayout(addtab);
        addtab.setLayout(addtabLayout);
        addtabLayout.setHorizontalGroup(
            addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addtabLayout.createSequentialGroup()
                .addGap(238, 238, 238)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addtabLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addtabLayout.createSequentialGroup()
                        .addComponent(ex, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(239, 239, 239)
                        .addComponent(jButton5)
                        .addGap(27, 27, 27)
                        .addComponent(addbt))
                    .addComponent(jLabel6)
                    .addGroup(addtabLayout.createSequentialGroup()
                        .addGroup(addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(day, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(combo, javax.swing.GroupLayout.Alignment.LEADING, 0, 150, Short.MAX_VALUE)
                                .addComponent(quant, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(dosage, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(135, 135, 135))
        );
        addtabLayout.setVerticalGroup(
            addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addtabLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(24, 24, 24)
                .addGroup(addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addtabLayout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(day, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(quant, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(combo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dosage, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ex, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5)
                    .addComponent(addbt))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        tabs.addTab("tab1", addtab);

        ipttab.setBackground(new java.awt.Color(163, 209, 198));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Update product");

        dayup.setBackground(new java.awt.Color(79, 149, 157));
        dayup.setForeground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("ID");

        tableup.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Day", "ID", "Name", "Balance", "Dosage Form", "Dosage type", "Exipry date"
            }
        ));
        tableup.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableupMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tableup);

        balanceup.setBackground(new java.awt.Color(79, 149, 157));
        balanceup.setForeground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Balance");

        exup.setBackground(new java.awt.Color(79, 149, 157));
        exup.setForeground(new java.awt.Color(255, 255, 255));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText(" Expire Date");

        upbott.setText("Update");
        upbott.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upbottActionPerformed(evt);
            }
        });

        idup.setBackground(new java.awt.Color(79, 149, 157));
        idup.setForeground(new java.awt.Color(255, 255, 255));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Day");

        del.setText("Delete");
        del.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ipttabLayout = new javax.swing.GroupLayout(ipttab);
        ipttab.setLayout(ipttabLayout);
        ipttabLayout.setHorizontalGroup(
            ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ipttabLayout.createSequentialGroup()
                .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ipttabLayout.createSequentialGroup()
                        .addGap(253, 253, 253)
                        .addComponent(jLabel8)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(ipttabLayout.createSequentialGroup()
                        .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ipttabLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dayup, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(balanceup, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(exup, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(idup, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel12)))
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ipttabLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(del)
                .addGap(80, 80, 80)
                .addComponent(upbott)
                .addGap(52, 52, 52))
        );
        ipttabLayout.setVerticalGroup(
            ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ipttabLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ipttabLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dayup, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(idup, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(balanceup, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(exup, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(upbott)
                    .addComponent(del))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        tabs.addTab("tab2", ipttab);

        viewtab.setBackground(new java.awt.Color(163, 209, 198));

        jScrollPane1.setBackground(new java.awt.Color(163, 209, 198));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Day", "ID", "Name", "Balance", "Dosage Form", "Dosage type", "Expire Date"
            }
        ));
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout viewtabLayout = new javax.swing.GroupLayout(viewtab);
        viewtab.setLayout(viewtabLayout);
        viewtabLayout.setHorizontalGroup(
            viewtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewtabLayout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        viewtabLayout.setVerticalGroup(
            viewtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewtabLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        tabs.addTab("tab4", viewtab);

        getContentPane().add(tabs, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, -40, 620, 610));

        jPanel1.setBackground(new java.awt.Color(251, 255, 228));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Welcome, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Welcome, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        tabs.setSelectedIndex(0);
        
        
    }//GEN-LAST:event_addActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
      tabs.setSelectedIndex(1);
      showupdata();
    }//GEN-LAST:event_updateActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
    tabs.setSelectedIndex(2);
    showdata();
    }//GEN-LAST:event_viewActionPerformed

    
    
    private void addbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbtActionPerformed
       Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure you want to Add this drug?", "add drug", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
            try {
            String sql="INSERT INTO `drugs`(`Day`, `Name`, `Quantity`,`Balance`, `Dosage Form`, `Dosage type`, `Expiry date`) VALUES (?,?,?,?,?,?,?)";
                       pst=con.prepareStatement(sql);
                       
                       pst.setString(1, day.getText());
                       pst.setString(2, name.getText());
                       pst.setString(3, quant.getText());
                         pst.setString(4, quant.getText());
                       pst.setString(5, combo.getSelectedItem().toString());
                       pst.setString(6, dosage.getText());
                       pst.setString(7, ex.getText());
 pst.executeUpdate();
           JOptionPane.showMessageDialog(rootPane, "inserted");
           showadddata();
            
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(rootPane, e);
        }
       }
      else
            System.out.println();
        
      
        
    }//GEN-LAST:event_addbtActionPerformed

    private void upbottActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upbottActionPerformed
           Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure you want to Update?", "update", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
         try {
            String sql="UPDATE `drugs` SET `Day`=?,`Balance`=?,`Expiry date`=? WHERE `ID`=?";
              pst=con.prepareStatement(sql);
            pst.setString(4, idup.getText());
             pst.setString(1, dayup.getText());
           pst.setString(2, balanceup.getText());
           pst.setString(3, exup.getText());
           pst.executeUpdate();
           JOptionPane.showMessageDialog(rootPane, "updated");
            showupdata();
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(rootPane, e);
        }
       }
      else
            System.out.println();
        
        
        
        
    }//GEN-LAST:event_upbottActionPerformed

    private void tableupMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableupMouseClicked
          int row = tableup.getSelectedRow();
        dayup.setText(tableup.getValueAt(row, 0).toString());
        balanceup.setText(tableup.getValueAt(row, 3).toString());
        exup.setText(tableup.getValueAt(row, 6).toString());
        idup.setText(tableup.getValueAt(row, 1).toString());
    }//GEN-LAST:event_tableupMouseClicked

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
      Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure wou want to exit?", "Exit", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
           System.exit(0);
       }
      else
            System.out.println();
    }//GEN-LAST:event_exitActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
          Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure wou want to log out?", "Log out", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
           new LogPage().setVisible(true);
           this.dispose();
       }
      else
            System.out.println();
    }//GEN-LAST:event_logoutActionPerformed

    private void delActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delActionPerformed
        
           Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure you want to Delete this drug?", "Delete", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
           try {
            String sql="DELETE FROM `drugs` WHERE ID=?";
            pst=con.prepareStatement(sql);
            pst.setString(1, idup.getText());
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(rootPane, "Drug Deleted");
            
        } catch (Exception e) {
        }
       }
      else
            System.out.println();
        
    }//GEN-LAST:event_delActionPerformed

    public void datetime(){
        Date d = new Date();
        LocalDateTime id=LocalDateTime.now();
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
           String FormatedDateTime=id.format(dtf);
          //date.setText(FormatedDateTime);
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       try {
    UIManager.setLookAndFeel( new FlatLightLaf() );
} catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MedicineStor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Welcome;
    private javax.swing.JButton add;
    private javax.swing.JButton addbt;
    private javax.swing.JPanel addtab;
    private javax.swing.JTextField balanceup;
    private javax.swing.JPanel bottpanel;
    private javax.swing.JComboBox<String> combo;
    private javax.swing.JTextField day;
    private javax.swing.JTextField dayup;
    private javax.swing.JButton del;
    private javax.swing.JTextField dosage;
    private javax.swing.JTextField ex;
    private javax.swing.JButton exit;
    private javax.swing.JTextField exup;
    private javax.swing.JTextField idup;
    private javax.swing.JPanel ipttab;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton logout;
    private javax.swing.JTextField name;
    private javax.swing.JTextField quant;
    private javax.swing.JTable table;
    private javax.swing.JTable tableadd;
    private javax.swing.JTable tableup;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JButton upbott;
    private javax.swing.JButton update;
    private javax.swing.JButton view;
    private javax.swing.JPanel viewtab;
    // End of variables declaration//GEN-END:variables
}
