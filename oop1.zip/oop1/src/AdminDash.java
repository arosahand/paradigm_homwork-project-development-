

import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.UIManager;
/*

 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Aro
 */
public class AdminDash extends javax.swing.JFrame {

  Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    public AdminDash(String username, String role) {
        initComponents();
        datetime();
        oop();
        showdata();
        //showadddata();
        showupdata();
        
        
        Welcome.setText("Logged in as: " + username + " (" + role + ")");
        
        
        
    }
    public AdminDash(){
          initComponents();
             
    }
      void oop(){
         try{
                con=DriverManager.getConnection("jdbc:mysql://localhost:3308/pharmacy", "root","");
                System.out.println("Connection Succsseful");
        }catch(SQLException e){
            System.out.println(e);
        }
    }
void showdata(){
        try {
            String sql="SELECT * FROM `employee`";
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
 
     
//void showadddata(){
//        try {
//            String sql="SELECT `Day`,`Name`, `Quantity`, `Dosage Form`, `Dosage type`, `Expiry date` FROM `drugs`";
//            pst=con.prepareStatement(sql);
//            rs=pst.executeQuery();
//            tableadd.setModel(DbUtils.resultSetToTableModel(rs));
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }

void showupdata(){
        try {
            String sql="SELECT `ID`, `Role`, `Username`, `Password` FROM `employee`";
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            tableup.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bottpanel = new javax.swing.JPanel();
        add = new javax.swing.JButton();
        update = new javax.swing.JButton();
        view = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        tabs = new javax.swing.JTabbedPane();
        addtab = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        dosage = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        ex = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        role = new javax.swing.JComboBox<>();
        addbot = new javax.swing.JButton();
        password = new javax.swing.JPasswordField();
        ryt = new javax.swing.JPasswordField();
        ipttab = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        ID = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableup = new javax.swing.JTable();
        user = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        pass = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        upbott = new javax.swing.JButton();
        passwor = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        del = new javax.swing.JButton();
        viewtab = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        Welcome = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin");
        setMinimumSize(new java.awt.Dimension(870, 568));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bottpanel.setBackground(new java.awt.Color(179, 216, 168));

        add.setBackground(new java.awt.Color(61, 141, 122));
        add.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        add.setForeground(new java.awt.Color(0, 0, 0));
        add.setText("Add Users");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        update.setBackground(new java.awt.Color(61, 141, 122));
        update.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        update.setForeground(new java.awt.Color(0, 0, 0));
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        view.setBackground(new java.awt.Color(61, 141, 122));
        view.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        view.setForeground(new java.awt.Color(0, 0, 0));
        view.setText("View");
        view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewActionPerformed(evt);
            }
        });

        exit.setBackground(new java.awt.Color(61, 141, 122));
        exit.setForeground(new java.awt.Color(0, 0, 0));
        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        logout.setBackground(new java.awt.Color(61, 141, 122));
        logout.setForeground(new java.awt.Color(0, 0, 0));
        logout.setText("Logout");
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(61, 141, 122));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Drug Storage");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bottpanelLayout = new javax.swing.GroupLayout(bottpanel);
        bottpanel.setLayout(bottpanelLayout);
        bottpanelLayout.setHorizontalGroup(
            bottpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bottpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 74, Short.MAX_VALUE)
                .addComponent(logout)
                .addGap(26, 26, 26))
            .addGroup(bottpanelLayout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addGroup(bottpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(update, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bottpanelLayout.setVerticalGroup(
            bottpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bottpanelLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(view, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 103, Short.MAX_VALUE)
                .addGroup(bottpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exit)
                    .addComponent(logout))
                .addGap(57, 57, 57))
        );

        getContentPane().add(bottpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 250, 470));

        tabs.setBackground(new java.awt.Color(64, 64, 0));

        addtab.setBackground(new java.awt.Color(163, 209, 198));
        addtab.setForeground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Dosage type");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Username");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Expirey Date");

        dosage.setBackground(new java.awt.Color(79, 149, 157));
        dosage.setForeground(new java.awt.Color(255, 255, 255));

        jButton5.setText("Clear all");

        ex.setBackground(new java.awt.Color(79, 149, 157));
        ex.setForeground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("Password");

        username.setBackground(new java.awt.Color(79, 149, 157));
        username.setForeground(new java.awt.Color(255, 255, 255));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("Re-type Password");

        role.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Managing role", "Admin", "DrugStorage", "FliudStorage", "SupplyStorage" }));

        addbot.setText("Add");
        addbot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbotActionPerformed(evt);
            }
        });

        password.setBackground(new java.awt.Color(79, 149, 157));
        password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password.setForeground(new java.awt.Color(0, 0, 0));
        password.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        ryt.setBackground(new java.awt.Color(79, 149, 157));
        ryt.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ryt.setForeground(new java.awt.Color(0, 0, 0));
        ryt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout addtabLayout = new javax.swing.GroupLayout(addtab);
        addtab.setLayout(addtabLayout);
        addtabLayout.setHorizontalGroup(
            addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addtabLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addtabLayout.createSequentialGroup()
                        .addGroup(addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addGroup(addtabLayout.createSequentialGroup()
                                .addComponent(ex, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(239, 239, 239)
                                .addComponent(jButton5))
                            .addComponent(jLabel6)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dosage, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ryt, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addContainerGap(152, Short.MAX_VALUE))
                    .addGroup(addtabLayout.createSequentialGroup()
                        .addComponent(role, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addtabLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(addbot)
                .addGap(22, 22, 22))
        );
        addtabLayout.setVerticalGroup(
            addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addtabLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ryt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(98, 98, 98)
                .addComponent(role, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(addbot)
                .addGap(397, 397, 397)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dosage, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(addtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ex, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabs.addTab("tab1", addtab);

        ipttab.setBackground(new java.awt.Color(163, 209, 198));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Update User");

        ID.setBackground(new java.awt.Color(79, 149, 157));
        ID.setForeground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Password");

        tableup.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Role", "Username", "Password"
            }
        ));
        tableup.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableupMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tableup);

        user.setBackground(new java.awt.Color(79, 149, 157));
        user.setForeground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Username");

        pass.setBackground(new java.awt.Color(79, 149, 157));
        pass.setForeground(new java.awt.Color(255, 255, 255));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Re-type Password");

        upbott.setText("Update");
        upbott.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upbottActionPerformed(evt);
            }
        });

        passwor.setBackground(new java.awt.Color(79, 149, 157));
        passwor.setForeground(new java.awt.Color(255, 255, 255));
        passwor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passworActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("ID");

        del.setText("Delete");
        del.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ipttabLayout = new javax.swing.GroupLayout(ipttab);
        ipttab.setLayout(ipttabLayout);
        ipttabLayout.setHorizontalGroup(
            ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ipttabLayout.createSequentialGroup()
                .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ipttabLayout.createSequentialGroup()
                        .addGap(253, 253, 253)
                        .addComponent(jLabel8)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(ipttabLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ID, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(user, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pass, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10)
                            .addComponent(jLabel12)
                            .addComponent(jLabel9)
                            .addComponent(jLabel11)
                            .addComponent(passwor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 446, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ipttabLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(del)
                .addGap(34, 34, 34)
                .addComponent(upbott)
                .addGap(52, 52, 52))
        );
        ipttabLayout.setVerticalGroup(
            ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ipttabLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ipttabLayout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addGroup(ipttabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(upbott)
                            .addComponent(del)))
                    .addGroup(ipttabLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ID, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(user, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(passwor, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pass, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        tabs.addTab("tab2", ipttab);

        viewtab.setBackground(new java.awt.Color(163, 209, 198));

        jScrollPane1.setBackground(new java.awt.Color(163, 209, 198));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Role", "Username", "Paswword"
            }
        ));
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout viewtabLayout = new javax.swing.GroupLayout(viewtab);
        viewtab.setLayout(viewtabLayout);
        viewtabLayout.setHorizontalGroup(
            viewtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewtabLayout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        viewtabLayout.setVerticalGroup(
            viewtabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewtabLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        tabs.addTab("tab4", viewtab);

        getContentPane().add(tabs, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, -40, 620, 610));

        jPanel1.setBackground(new java.awt.Color(251, 255, 228));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Welcome, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Welcome, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        tabs.setSelectedIndex(0);
        
        
    }//GEN-LAST:event_addActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
      tabs.setSelectedIndex(1);
      showupdata();
    }//GEN-LAST:event_updateActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
    tabs.setSelectedIndex(2);
    showdata();
    }//GEN-LAST:event_viewActionPerformed

    
    
    private void upbottActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upbottActionPerformed
        try {
            String sql="UPDATE `employee` SET `Username`=?,`Password`=? WHERE `ID`=?";
          if(passwor.getText().equals(pass.getText())){
              pst=con.prepareStatement(sql);
                       pst.setString(3, ID.getText());
                       pst.setString(1, user.getText());
                       pst.setString(2, passwor.getText());
                       
                       
                        
                            pst.executeUpdate();
           JOptionPane.showMessageDialog(rootPane, "Account Updated");
                        }
                       
            else{ 
                           JOptionPane.showMessageDialog(rootPane, "Password dont match, Please Check your password and try again");
            }
            
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(rootPane, e);
        }
        
    }//GEN-LAST:event_upbottActionPerformed

    private void tableupMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableupMouseClicked
          int row = tableup.getSelectedRow();
        ID.setText(tableup.getValueAt(row, 0).toString());
        user.setText(tableup.getValueAt(row, 2).toString());
        passwor.setText(tableup.getValueAt(row, 3).toString());
    }//GEN-LAST:event_tableupMouseClicked

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
      Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure wou want to exit?", "Exit", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
           System.exit(0);
       }
      else
            System.out.println();
    }//GEN-LAST:event_exitActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
          Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure you want to log out?", "Log out", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
           new LogPage().setVisible(true);
           this.dispose();
       }
      else
            System.out.println();
    }//GEN-LAST:event_logoutActionPerformed

    private void addbotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbotActionPerformed
       
         Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure you want to create the account?", "Create", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
            try {
            String sql="INSERT INTO `employee`( `Username`, `Password`, `Role`) VALUES (?,?,?)";
            if(password.getText().equals(ryt.getText())){
              pst=con.prepareStatement(sql);
                       
                       pst.setString(1, username.getText());
                       pst.setString(2, password.getText());
                       pst.setString(3, role.getSelectedItem().toString());
                        }
            else{ 
                           JOptionPane.showMessageDialog(rootPane, "Password dont match, Please Check your password and try again");
            }
          
        } catch (Exception e) {
            
        }
       }
      else
            System.out.println();
    }//GEN-LAST:event_addbotActionPerformed

    private void passworActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passworActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passworActionPerformed

    private void delActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delActionPerformed
        Object[] op={"Yes","No"};
        int chose=JOptionPane.showOptionDialog(null, "Are you sure wou want to Delete this account?", "Delete", 0, JOptionPane.QUESTION_MESSAGE, null, op, op[0]);
        
       if(chose==0){
           try {
            String sql="DELETE FROM `employee` WHERE ID=?";
            pst=con.prepareStatement(sql);
            pst.setString(1, ID.getText());
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(rootPane, "Account Deleted");
            
        } catch (Exception e) {
        }
       }
      else
            System.out.println();
        
    }//GEN-LAST:event_delActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      new MedicineStor().setVisible(true);
      this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    public void datetime(){
        Date d = new Date();
        LocalDateTime id=LocalDateTime.now();
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
           String FormatedDateTime=id.format(dtf);
          //date.setText(FormatedDateTime);
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       try {
    UIManager.setLookAndFeel( new FlatLightLaf() );
} catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MedicineStor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ID;
    private javax.swing.JLabel Welcome;
    private javax.swing.JButton add;
    private javax.swing.JButton addbot;
    private javax.swing.JPanel addtab;
    private javax.swing.JPanel bottpanel;
    private javax.swing.JButton del;
    private javax.swing.JTextField dosage;
    private javax.swing.JTextField ex;
    private javax.swing.JButton exit;
    private javax.swing.JPanel ipttab;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton logout;
    private javax.swing.JTextField pass;
    private javax.swing.JTextField passwor;
    private javax.swing.JPasswordField password;
    private javax.swing.JComboBox<String> role;
    private javax.swing.JPasswordField ryt;
    private javax.swing.JTable table;
    private javax.swing.JTable tableup;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JButton upbott;
    private javax.swing.JButton update;
    private javax.swing.JTextField user;
    private javax.swing.JTextField username;
    private javax.swing.JButton view;
    private javax.swing.JPanel viewtab;
    // End of variables declaration//GEN-END:variables
}
