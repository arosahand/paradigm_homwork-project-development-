
package drug;


public class tablet extends medicine {
    
    private String mg;
    
    
   public void setmg(String mg){
       this.mg=mg;
   } 
    
   public String getmg(){
       return mg;
   }
}
