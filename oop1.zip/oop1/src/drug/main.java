
package drug;

import java.util.Scanner;


public class main {
    public static void main(String[] args) {
        
        syrup s=new syrup();
        tablet t= new tablet();
        
        
        
        s.setName("Paractamol");
        s.setId(1);
        s.setPrice(2);
        s.setExpireDate("2025-12-12");
        s.setProductionDate("2024-02-04");
        s.setml("500mg/5mL");
        
        
        
        t.setName("Paractamol");
        t.setId(1);
        t.setPrice(2);
        t.setExpireDate("2025-12-11");
        t.setProductionDate("2024-02-07");
        t.setmg("500mg");
        
        
        
        Scanner user= new Scanner(System.in);
        
        System.out.println("What type of paractamol you want?\n1. Tablet\n2.Syrup");
        int op=user.nextInt();
        
        switch(op){
            case 1:
                System.out.println("ID: "+t.getId());
                System.out.println("Name: "+t.getName());
                System.out.println("Price: $"+t.getPrice());
                System.out.println("Production Date: "+t.getProductionDate());
                System.out.println("Expire Date: "+t.getExpireDate());
                System.out.println("mg: "+t.getmg());
                break;
                
            case 2:
                System.out.println("ID: "+s.getId());
                System.out.println("Name: "+s.getName());
                System.out.println("Price: $"+s.getPrice());
                System.out.println("Production Date: "+s.getProductionDate());
                System.out.println("Expire Date: "+s.getExpireDate());
                System.out.println("mg: "+s.getml());
                break;
       }
    }
}
